# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.scripts', 'gendiff.tests']

package_data = \
{'': ['*'], 'gendiff.tests': ['fixtures/*']}

install_requires = \
['PyYAML>=5.3.1,<6.0.0',
 'flake8>=3.8.4,<4.0.0',
 'pytest-cov>=2.10.1,<3.0.0',
 'pytest>=6.2.1,<7.0.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.4',
    'description': '',
    'long_description': None,
    'author': 'Егор',
    'author_email': 'oegor8194@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
